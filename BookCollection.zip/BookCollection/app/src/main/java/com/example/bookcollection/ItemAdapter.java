package com.example.bookcollection;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.app.AlertDialog;
import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder> {

    private final Context context;
    private final List<Item> items;

    // Constructor to initialize context and list of items
    public ItemAdapter(Context context, List<Item> items) {
        this.context = context;
        this.items = items;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the item layout (book_list.xml) for each item in RecyclerView
        View view = LayoutInflater.from(context).inflate(R.layout.book_list, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // Get the current item from the list
        Item item = items.get(position);

        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, updateActivity.class);
            intent.putExtra("id", item.getId());  // Pass item ID or other needed data
            context.startActivity(intent);
        });

        // Bind the data from the item to the respective views
        holder.titleTextView.setText(item.getTitle());
        holder.authorTextView.setText(item.getAuthor());
        holder.categoryTextView.setText(item.getCategory());


        // Set listener for the delete button
        holder.deleteButton.setOnClickListener(v -> {
            // Show confirmation dialog before deleting
            new AlertDialog.Builder(context)
                    .setTitle("Confirm Delete")
                    .setMessage("Are you sure you want to delete this item?")
                    .setPositiveButton("Yes", (dialog, which) -> {
                        // Remove item from list
                        items.remove(position);
                        // Optionally, delete item from database
                        DatabaseHelper databaseHelper = new DatabaseHelper(context);
                        databaseHelper.deleteItem(item.getId()); // Ensure you implement deleteItem method in your DatabaseHelper
                        // Notify adapter about the data change
                        notifyItemRemoved(position);
                        Toast.makeText(context, "Item deleted", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("No", null)
                    .show();
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    // Inner class to hold the views for each item in RecyclerView
    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView titleTextView, authorTextView, categoryTextView;
        CheckBox readCheckBox, unreadCheckBox;
        Button deleteButton;  // Add reference to delete button

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // Initialize views from the item layout (book_list.xml)
            titleTextView = itemView.findViewById(R.id.titleTextView);
            authorTextView = itemView.findViewById(R.id.authorTextView);
            categoryTextView = itemView.findViewById(R.id.categoryTextView);
            readCheckBox = itemView.findViewById(R.id.readCheckBox);
            unreadCheckBox = itemView.findViewById(R.id.unreadCheckBox);
            deleteButton = itemView.findViewById(R.id.deleteButton); // Find the delete button
        }
    }
}
