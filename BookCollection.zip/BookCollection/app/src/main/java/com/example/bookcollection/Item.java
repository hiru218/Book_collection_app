package com.example.bookcollection;

public class Item {
    private int id;
    private String title;
    private String author;
    private String category;

    public Item(int id, String title, String author, String category) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.category = category;
    }

    public Item(String title, String author, String category) {
        this.title = title;
        this.author = author;
        this.category = category;
    }

    public int getId() {
        return id;
    }
    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getCategory() {
        return category;
    }

    }

