package com.example.bookcollection;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class DatabaseHelper extends SQLiteOpenHelper {

private  Context context;

public static final String DATABASE_NAME ="BookLibrary.db" ;
public static final int DATABASE_VERSION = 1;
public static  final String TABLE_NAME = "Mylibrary" ;
public static  final  String COLUMN_ID = "_id";
public  static final String COLUMN_TITLE = "booktitle";
public  static final String COLUMN_AUTHOR = "bookauthor";
public  static final String COLUMN_CATEGORY = "bookcategory";



    public DatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context=context;
    }


    //table create method
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        sqLiteDatabase.execSQL("CREATE TABLE "+ TABLE_NAME+" ("+
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_TITLE + " TEXT," +
                COLUMN_AUTHOR + " TEXT," +
                COLUMN_CATEGORY + " TEXT)");
    }


    //upgrade method
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS "+ TABLE_NAME);
        onCreate(sqLiteDatabase);

    }

//adding book method
    public void addBook (String booktitle, String bookauthor, String bookcategory) {
        SQLiteDatabase db = this.getWritableDatabase ();
        ContentValues values = new ContentValues () ;

        values.put (COLUMN_TITLE, booktitle) ;
        values.put (COLUMN_AUTHOR, bookauthor) ;
        values.put (COLUMN_CATEGORY, bookcategory) ;

        long result = db. insert (TABLE_NAME , null,values) ;
        if (result ==- 1) {
            Toast.makeText (context,  "Failed", Toast. LENGTH_SHORT) .show () ;
        }else {
            Toast.makeText (context,  "Added successfully!", Toast. LENGTH_SHORT) . show () ;
        }
    }


    //read data method
    Cursor readAllData() {
        String query = "SELECT * FROM " + TABLE_NAME;

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = null;

        if (db != null) {
            cursor = db.rawQuery(query, null);
        }
        return cursor;
    }


    public Cursor getItemById(int id) {
        SQLiteDatabase db = (this).getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_NAME + " WHERE " + COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
    }

    public void updateItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, item.getTitle());
        values.put(COLUMN_AUTHOR, item.getAuthor());
        values.put(COLUMN_CATEGORY, item.getCategory());

        db.update(TABLE_NAME, values, COLUMN_ID + " = ?", new String[]{String.valueOf(item.getId())});
        db.close();
    }
    public void deleteItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rowsAffected = db.delete(TABLE_NAME, COLUMN_ID + " = ?", new String[]{String.valueOf(id)});
        db.close();
    }
}

