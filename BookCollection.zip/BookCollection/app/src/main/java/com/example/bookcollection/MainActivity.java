
package com.example.bookcollection;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int ADD_BOOK_REQUEST_CODE = 1;
    private RecyclerView recyclerView;
    private ItemAdapter itemAdapter;
    private DatabaseHelper myDB;
    private List<Item> items;
    private FloatingActionButton add_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerid);
        add_button = findViewById(R.id.add_button);

         //Open AddActivity when the add button is clicked
        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddActivity.class);
                startActivity(intent);
            }
        });

        myDB = new DatabaseHelper(MainActivity.this);
        items = new ArrayList<>();

        // Initialize the ItemAdapter with the items list
        itemAdapter = new ItemAdapter(MainActivity.this, items);
        recyclerView.setAdapter(itemAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));

        // Load data into the RecyclerView
        storeDataInItemsList();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ADD_BOOK_REQUEST_CODE && resultCode == RESULT_OK) {
            // Refresh data when returning from AddActivity
            storeDataInItemsList();
        }


    }

    @SuppressLint("NotifyDataSetChanged")
    private void storeDataInItemsList() {
        items.clear(); // Clear the list before adding new data
        Cursor cursor = myDB.readAllData();
        if (cursor.getCount() == 0) {
            Toast.makeText(this, "No Data", Toast.LENGTH_SHORT).show();
        } else {
            while (cursor.moveToNext()) {
                // Retrieve data from cursor and add it as Item objects to the list
                int id = cursor.getInt(0);
                String title = cursor.getString(1);
                String author = cursor.getString(2);
                String category = cursor.getString(3);

                // Add a new Item to the list
                items.add(new Item(id, title, author, category));
            }
            itemAdapter.notifyDataSetChanged(); // Notify adapter of data changes
        }
        cursor.close(); // Close cursor to prevent memory leaks

    }
}

