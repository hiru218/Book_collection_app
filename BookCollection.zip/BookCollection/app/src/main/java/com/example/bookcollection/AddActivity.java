package com.example.bookcollection;//package com.example.bookcollection;




import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class AddActivity extends AppCompatActivity {

    EditText editTitle, editAuthor, editCategory;
    Button buttonAdd, buttonRead;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        editTitle = findViewById(R.id.editTitle);
        editAuthor = findViewById(R.id.editAuthor);
        editCategory = findViewById(R.id.editCategory);

        buttonAdd = findViewById(R.id.buttonAdd);
        buttonRead = findViewById(R.id.buttonRead);


        // Add record to the database
        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                DatabaseHelper myDB = new DatabaseHelper(AddActivity.this);
                myDB.addBook(editTitle.getText().toString().trim(),
                        editAuthor.getText().toString().trim(),
                        editCategory.getText().toString().trim()

                );

                // Clear input fields after adding the book
                editTitle.setText("");
                editAuthor.setText("");
                editCategory.setText("");
            }
        });

        // View library data in MainActivity
        buttonRead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Navigate to MainActivity to view data
                Intent intent = new Intent(AddActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });


        //update Library data




    }
}