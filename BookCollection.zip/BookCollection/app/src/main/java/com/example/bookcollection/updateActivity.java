package com.example.bookcollection;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class updateActivity extends AppCompatActivity {

    private EditText editTextTitle;
    private EditText editTextAuthor;
    private EditText editTextCategory;
    private Button buttonUpdate;
    private DatabaseHelper databaseHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_update);
            // Initialize UI components
            editTextTitle = findViewById(R.id.editTitle_update);
            editTextAuthor = findViewById(R.id.editAuthor_update);
            editTextCategory = findViewById(R.id.editCategory_update);
            buttonUpdate = findViewById(R.id.buttonUpdate);

            // Initialize database helper
            databaseHelper = new DatabaseHelper(this);

            // Get the item ID passed from RecyclerViewActivity
            Intent intent = getIntent();
            final int itemId = intent.getIntExtra("id", -1);
            String bookname = intent.getStringExtra("booktitle");
            String bookauther = intent.getStringExtra("bookauther");
            String bookcategory = intent.getStringExtra("bookcategory");
            Log.d("updateActivity", "Received Item ID: " + itemId);  // Add this to check ID

            editTextTitle.setText(bookname);
            editTextAuthor.setText(bookauther);
            editTextCategory.setText(bookcategory);


            // Set up the update button to save changes
            buttonUpdate.setOnClickListener(v -> {
                String updatebooktitle = editTextTitle.getText().toString().trim();
                String updatebookauther = editTextAuthor.getText().toString().trim();
                String updatebookcategory = editTextCategory.getText().toString().trim();

                if (updatebooktitle.isEmpty() || updatebookauther.isEmpty() || updatebookcategory.isEmpty()) {
                    Toast.makeText(updateActivity.this, "Please fill out all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                Item updatedbook = new Item(itemId,updatebooktitle,updatebookauther,updatebookcategory);
                databaseHelper.updateItem(updatedbook);

                Toast.makeText(updateActivity.this,"Book updated", Toast.LENGTH_SHORT).show();

                Intent resultIntent = new Intent();
                setResult(RESULT_OK,resultIntent);
                finish();
            });

    }
}